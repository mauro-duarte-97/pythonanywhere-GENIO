# from django.db import models
# from apps.custom_user import models as custom_user

# class AuthUserProfile(models.Model):
    # user = models.OneToOneField(custom_user.CustomUser, on_delete=models.CASCADE)
    # is_verified = models.BooleanField(default=False)
    # dni = models.CharField(max_length=8, blank=True, null=True)