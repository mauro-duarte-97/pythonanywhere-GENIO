from django.apps import AppConfig


class CursadaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.cursada'
